opencv_version = "4.5.2.54"
contrib = False
headless = True
ci_build = True